THE $0 EDIT VS $100 EDIT: PROJECT ASSETS

These are the working files behind the before and after edit. The frame is vertical, 1080 x 1920, 25 frames a second.
No video, audio or sound effects are in this pack. You bring your own clip.

WHAT IS INSIDE

illustrations/
  5 comic drawings as SVG files. They are the pictures on the paper prints in the 3 cutaways.
  c1_mirror.svg   a person facing a mirror
  c2_tripod.svg   a phone on a tripod and an empty stool
  c2_faces.svg    a row of faces lit by one screen
  c3_head.svg     a head in profile
  c3_map.svg      a map
  How to open: drag a file into a browser, or open it in Figma, Illustrator, Inkscape or Affinity.

layout/
  before-after-shell.html
  The before and after layout: the small card, the big card, the 2 labels and the comment line.
  Grey boxes show where the 2 videos go. Every position and size is in the CSS at the top of the file.
  How to open: double-click it. It opens in your browser.

captions/
  caption-voices-demo.html
  The 3 caption styles: small words, the big word and the handwritten line.
  It also plays the 4-frame flicker of the big word. You can pause it and step 1 frame at a time.
  How to open: double-click it.

3d-prints/
  paper-print-cutaway.html   the first cutaway as a 3D scene: a print on a desk with tape, labels and a moving camera
  c1_mirror.svg              the picture on the print
  prompt.txt                 the prompt the 3D scenes were built from. Paste it into an AI coding tool and change the subject.
  How to open: double-click paper-print-cutaway.html. It loads Three.js 0.160.0 from unpkg.com, so you need the internet.
  The label and handwriting text are placeholders. Change LABEL_TEXT and HAND_TEXT near the top of the script.
  The picture is stored inside the HTML file, so the page works straight from a folder. The notes at the top of the
  script say how to swap it.

palette-and-fonts.txt
  The 5 colours with their hex codes, and the 3 fonts with their Google Fonts links.

GOOD TO KNOW

- The 3 HTML files load their fonts from Google Fonts. With no internet, the text shows in a fallback font.
- Open the HTML files in a text editor to read the code. The comments explain each part.
- In the 3D scene, every frame is set from the frame number. Call draw(150) in the browser console to see frame 150.
