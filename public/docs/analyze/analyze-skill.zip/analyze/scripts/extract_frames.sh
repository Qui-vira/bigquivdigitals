#!/usr/bin/env bash
# Extract hook frames plus scene changes from a reel.
# Avoids fixed-fps sampling, which produces mostly duplicate frames.
#
# Usage: ./extract_frames.sh input.mp4 [outdir] [threshold]
#   threshold: scene change sensitivity 0.0-1.0, default 0.3
#              lower = more frames, higher = fewer
#
# Requires: ffmpeg

set -euo pipefail

IN="${1:?usage: extract_frames.sh input.mp4 [outdir] [threshold]}"
OUT="${2:-frames}"
THRESH="${3:-0.3}"

command -v ffmpeg >/dev/null || { echo "ffmpeg not found"; exit 1; }
[ -f "$IN" ] || { echo "no such file: $IN"; exit 1; }

mkdir -p "$OUT"
rm -f "$OUT"/hook_*.jpg "$OUT"/scene_*.jpg

# Hook: first 3 seconds at 1fps. This is where the decision to keep watching happens.
ffmpeg -loglevel error -y -i "$IN" -t 3 -vf fps=1 -q:v 3 "$OUT/hook_%02d.jpg"

# Body: one frame per scene change.
ffmpeg -loglevel error -y -i "$IN" \
  -vf "select='gt(scene,${THRESH})',showinfo" \
  -vsync vfr -q:v 3 "$OUT/scene_%03d.jpg" 2>/dev/null || true

HOOK=$(ls "$OUT"/hook_*.jpg 2>/dev/null | wc -l)
SCENE=$(ls "$OUT"/scene_*.jpg 2>/dev/null | wc -l)
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$IN" 2>/dev/null | cut -d. -f1)

echo "$OUT: $HOOK hook + $SCENE scene = $((HOOK+SCENE)) frames from ${DUR}s"
echo "fixed 1fps would have produced ${DUR}"

if [ "$SCENE" -eq 0 ]; then
  echo "no scene changes detected. single-take reel, or raise sensitivity: $0 $IN $OUT 0.15"
fi
