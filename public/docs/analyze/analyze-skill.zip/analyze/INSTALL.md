# How to install the /analyze skill

/analyze breaks down any short-form video (Instagram Reels, TikTok, YouTube Shorts): real views and
likes, an outlier score against the creator's normal, a real transcript, real frames, the hook,
structure and a template you can reuse.

It runs inside **Claude Code**. Everything it uses is free.

---

## Step 1. Install the tools it uses

**Windows** (PowerShell):

    winget install yt-dlp.yt-dlp
    winget install Gyan.FFmpeg
    winget install Python.Python.3.12
    pip install faster-whisper

**Mac** (Terminal):

    brew install yt-dlp ffmpeg python
    pip3 install faster-whisper

Close and reopen the terminal, then check:

    yt-dlp --version
    ffmpeg -version

On Windows, Claude Code already needs Git for Windows (Git Bash). The frame script runs in it.

## Step 2. Install Scrapling (needed for Instagram)

Scrapling pulls Instagram likes, comments, view counts and the live comment list with no login.

    pip install "scrapling[ai]"
    scrapling install

Find where it installed:

    where scrapling-mcp        (Windows)
    which scrapling-mcp        (Mac)

Add it to Claude Code, using the path you just got:

    claude mcp add --scope user scrapling -- "<path to scrapling-mcp>"

## Step 3. Put the skill in place

Unzip so the folder sits here:

- Windows: `C:\Users\<your name>\.claude\skills\analyze\SKILL.md`
- Mac: `~/.claude/skills/analyze/SKILL.md`

The `scripts` folder goes inside `analyze` too.

## Step 4. Set your browser (for downloading Instagram videos)

Instagram only hands over the video file to a logged-in browser. The skill is set to **Brave**.
If you use another browser, open `SKILL.md`, search for `--cookies-from-browser brave`, and change
`brave` to your browser (`firefox`, `edge`, `chrome`, `safari`). Stay logged in to Instagram in that browser.

Notes from testing on Windows: Chrome often fails ("Failed to decrypt with DPAPI"), Edge must be fully
closed first, Brave and Firefox work. Your cookies are only read by yt-dlp on your own machine.

## Step 5. Use it

Restart Claude Code, then type:

    /analyze https://www.instagram.com/reel/XXXXXXXX/

Several links at once give you a teardown of each plus a pattern report across all of them.

## If something fails

- **TikTok times out:** run it again. The skill retries with a longer timeout.
- **"Instagram sent an empty media response":** your browser is not logged in, or the browser name in
  Step 4 is wrong.
- **Transcript is empty:** the video has no speech (music or text only). That is a real result.
- **Slow transcripts:** the skill uses the `small` Whisper model on purpose; smaller ones mishear words.
